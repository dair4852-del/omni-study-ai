from pathlib import Path
import os
from kivy.app import App
from kivy.lang import Builder
from kivy.metrics import dp
from kivy.properties import StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.clock import Clock

import omni_core as core

KV = r'''
<Root>:
    orientation: 'vertical'
    padding: dp(14)
    spacing: dp(10)
    canvas.before:
        Color:
            rgba: (0.035, 0.055, 0.10, 1)
        Rectangle:
            pos: self.pos
            size: self.size
    Label:
        text: '[b]OMNI STUDY AI[/b]  [color=65d6ff]v7[/color]'
        markup: True
        font_size: '24sp'
        size_hint_y: None
        height: dp(46)
        color: (1,1,1,1)
    Spinner:
        id: mode
        text: root.mode_name
        values: ['Домашка','Объяснение','Шпаргалка','Текст','Языки','Свободный режим']
        size_hint_y: None
        height: dp(48)
        on_text: root.change_mode(self.text)
    ScrollView:
        do_scroll_x: False
        Label:
            id: output
            text: root.output
            markup: False
            size_hint_y: None
            height: self.texture_size[1] + dp(24)
            text_size: self.width - dp(12), None
            halign: 'left'
            valign: 'top'
            color: (0.92,0.95,1,1)
            font_size: '16sp'
    TextInput:
        id: prompt
        hint_text: 'Напиши вопрос или задачу…'
        multiline: True
        size_hint_y: None
        height: dp(100)
        font_size: '16sp'
    Button:
        text: 'ОТПРАВИТЬ'
        size_hint_y: None
        height: dp(50)
        background_normal: ''
        background_color: (0.05,0.48,0.72,1)
        on_release: root.send()
    BoxLayout:
        size_hint_y: None
        height: dp(44)
        spacing: dp(8)
        Button:
            text: 'Заметки'
            on_release: root.show_notes()
        Button:
            text: 'История'
            on_release: root.show_history()
        Button:
            text: 'Справка'
            on_release: root.show_help()
'''

class Root(BoxLayout):
    output = StringProperty('Привет! Выбери режим и напиши вопрос.\n\nВажно: без API-ключа доступны локальные функции и шаблонные ответы.')
    mode_name = StringProperty('Свободный режим')
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.data = core.load_data()
        self.mode = self.data.get('mode', '6')
        self.mode_name = core.MODES[self.mode][0]
        self.output = core.brief(self.data) or self.output
    def change_mode(self, name):
        mapping = {v[0]: k for k,v in core.MODES.items()}
        if name in mapping:
            self.mode = mapping[name]
            self.data['mode'] = self.mode
            core.save_data(self.data)
    def append(self, value):
        self.output = (self.output + '\n\n' + value).strip()
    def send(self):
        q = self.ids.prompt.text.strip()
        if not q: return
        self.ids.prompt.text = ''
        if len(q) > core.MAX_INPUT:
            self.append('Слишком длинное сообщение. Максимум 4000 символов.')
            return
        self.append('Ты: ' + q)
        try:
            if q.startswith('!'):
                # Простые команды с безопасным выводом в мобильный экран.
                cmd, _, arg = q.partition(' ')
                if cmd.lower() in ('!help','!помощь'):
                    self.append(core.print_help.__doc__ or 'Команды: !calc выражение, !note ключ -> текст, !notes, !history, !stats, !today, !dashboard, !tools')
                    return
                if cmd.lower() in ('!notes','!заметки'):
                    self.show_notes(); return
                if cmd.lower() in ('!history','!история'):
                    self.show_history(); return
                if cmd.lower() in ('!calc','!счёт'):
                    self.append(f'{arg} = {core.calculate(arg)}'); return
                if cmd.lower() in ('!note','!заметка') and '->' in arg:
                    k,v = arg.split('->',1); self.data['notes'][k.strip().lower()] = v.strip(); core.save_data(self.data); self.append('Заметка сохранена.'); return
                self.append('Эта команда пока не подключена в мобильном интерфейсе. Напиши !help для списка основных функций.')
                return
            answer, src = core.respond(self.mode, q, self.data)
            core.add_history(self.data, self.mode, q, answer, src)
            core.save_data(self.data)
            self.append('OMNI: ' + answer)
        except Exception as e:
            self.append('Ошибка: ' + type(e).__name__ + ': ' + str(e))
    def show_notes(self):
        notes = self.data.get('notes', {})
        self.append('ЗАМЕТКИ\n' + ('\n'.join(f'• {k}: {v}' for k,v in notes.items()) if notes else 'Пока нет заметок. Добавь: !note тема -> текст'))
    def show_history(self):
        hist = self.data.get('history', [])[-10:]
        self.append('ИСТОРИЯ\n' + ('\n\n'.join('Ты: '+h.get('user','')+'\nOMNI: '+h.get('assistant','') for h in hist) if hist else 'История пока пустая.'))
    def show_help(self):
        self.append('КОМАНДЫ\n!calc 2+2 — калькулятор\n!note тема -> текст — сохранить заметку\n!notes — заметки\n!history — последние сообщения\n\nВыбери режим в списке сверху.')

class OmniApp(App):
    def build(self):
        self.title = 'OMNI STUDY AI'
        Builder.load_string(KV)
        return Root()
    def on_stop(self):
        if hasattr(self.root, 'data'): core.save_data(self.root.data)

if __name__ == '__main__':
    OmniApp().run()
