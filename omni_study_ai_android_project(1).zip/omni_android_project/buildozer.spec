[app]
title = OMNI STUDY AI
package.name = omnistudyai
package.domain = org.omnistudy
source.dir = .
source.include_exts = py,png,jpg,kv,json,txt
version = 1.0.0
requirements = python3,kivy
orientation = portrait
fullscreen = 0
android.permissions = INTERNET
android.api = 35
android.minapi = 23
android.archs = arm64-v8a, armeabi-v7a

[buildozer]
log_level = 2
warn_on_root = 1
