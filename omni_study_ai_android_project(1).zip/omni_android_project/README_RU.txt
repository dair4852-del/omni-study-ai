OMNI STUDY AI — проект Android APK

Состав:
- main.py — мобильный интерфейс Kivy
- omni_core.py — исходная логика OMNI STUDY AI v7
- buildozer.spec — настройки Android-сборки
- .github/workflows/build-apk.yml — автоматическая сборка APK через GitHub Actions

Как собрать через GitHub:
1. Загрузить ВСЕ файлы и папку .github/workflows в корень репозитория omni-study-ai.
2. Открыть вкладку Actions.
3. Выбрать “Build OMNI STUDY AI APK”.
4. Нажать “Run workflow”.
5. После завершения открыть успешный запуск и скачать Artifact “omni-study-ai-apk”.
6. Распаковать ZIP артефакта и установить APK на Android.

Примечание: это первая мобильная оболочка. Она подключает общую логику ядра v7, историю, заметки и калькулятор; часть интерактивных консольных инструментов ещё не перенесена в экранные элементы. Онлайн-ответы требуют отдельного API-ключа; ключ нельзя вшивать в APK.
